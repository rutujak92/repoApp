repoApp.config(['$routeProvider',function ($routeProvider) {
    $routeProvider
        .when('/', {
            templateUrl: 'public/tmpl/home.html',
            controller: 'homeController'
        }).otherwise({
            redirectTo: '/'
        });
}]);