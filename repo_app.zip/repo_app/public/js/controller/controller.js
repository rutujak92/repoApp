/*  homeController controller sets or gets data from or to view */


repoApp.controller("homeController", ['$scope','$http','repoData',function ($scope,$http,repoData) {

  $scope.saveUser = function(data, id) {//called for posting new data
    angular.extend(data, {id: id});
    name=data.name;
    desc=data.desc;
    fullname=data.fullname;
    type=data.type;
    return $http({
            method : "POST",
            url: 'https://requestb.in/10iliav1',
            data: $.param({ 'name': name,'desc':desc,'fullname':fullname,'type':type }),
            headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
            crossDomain: true,
            }).then(function mySuccess(response) {
              return response.data.message;
            }, function myError(response) {
                return response.statusText;
            });
    };
    $scope.repoData = new repoData();//load table with data
}]);

