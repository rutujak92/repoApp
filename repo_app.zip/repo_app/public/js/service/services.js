/*  repoData factory loads the data from the url  */

repoApp.factory('repoData', function($http) {
  var repoData = function() {
    this.items = [];
    this.busy = false;
    this.link = 'https://api.github.com/repositories?since=862';
  };//constructor function which assigns values to object properties

  repoData.prototype.nextPage = function() {
    if (this.busy) return;
      this.busy = true;

    var url = this.link;
    $http.get(url).then(function(res, status, headers, config) {
		  next_link = res.headers().link.split(';');//extract link from header
		
      var items = res.data;
      for (var i = 0; i < items.length; i++) {
      	
        this.items.push(items[i]);//construct items array
      }
      this.link = next_link[0].replace('<','').replace('>','');
      this.busy = false;
    }.bind(this));
  };

  return repoData;//return data to controller
});