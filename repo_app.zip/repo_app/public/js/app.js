var repoApp = angular.module('repoApp', ['ngRoute','ngResource','infinite-scroll','xeditable']);

repoApp.run(function(editableOptions) {
  editableOptions.theme = 'bs3';
});
